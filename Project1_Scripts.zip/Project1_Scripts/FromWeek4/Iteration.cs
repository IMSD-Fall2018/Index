﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Iteration : MonoBehaviour {

	public GameObject[] gos;

	// Use this for initialization
	void Start () {
		for(int i = 0; i < gos.Length; i++){
			Instantiate(gos[i], new Vector3(i - 2, 0, 0), Quaternion.identity);
		}
	}
}
